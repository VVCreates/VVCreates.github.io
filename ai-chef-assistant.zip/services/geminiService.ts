
import { GoogleGenAI, Type } from "@google/genai";
import { Ingredient, Recipe } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeFridgeImage(base64Images: string[]): Promise<Ingredient[]> {
  const imageParts = base64Images.map(base64 => ({
    inlineData: {
      mimeType: 'image/jpeg',
      data: base64,
    },
  }));

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        ...imageParts,
        {
          text: "Analyze these images of a fridge, pantry, or freezer. List all visible ingredients found across all photos. For items that might be easily confused (like cilantro and parsley, or sour cream and yogurt), provide a list of possible alternates. Return a JSON array of objects.",
        }
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            possibleAlternates: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["name", "possibleAlternates"]
        }
      }
    }
  });

  const rawData = JSON.parse(response.text);
  return rawData.map((item: any, index: number) => ({
    id: `ing-${Date.now()}-${index}`,
    name: item.name,
    possibleAlternates: item.possibleAlternates || [],
  }));
}

export async function generateRecipes(ingredients: string[], existingRecipeTitles: string[] = []): Promise<Recipe[]> {
  const prompt = `Based on these ingredients: ${ingredients.join(", ")}. Provide 3 unique recipe suggestions. ${
    existingRecipeTitles.length > 0 
    ? `Do NOT suggest these previously provided recipes: ${existingRecipeTitles.join(", ")}.` 
    : ""
  } For each recipe, provide a title, description, prep time, difficulty, a list of specific ingredients needed from the list (plus common pantry staples), and step-by-step instructions.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            prepTime: { type: Type.STRING },
            difficulty: { type: Type.STRING },
            ingredientsNeeded: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            instructions: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["title", "description", "prepTime", "difficulty", "ingredientsNeeded", "instructions"]
        }
      }
    }
  });

  const rawData = JSON.parse(response.text);
  return rawData.map((item: any, index: number) => ({
    ...item,
    id: `rec-${Date.now()}-${index}`
  }));
}
