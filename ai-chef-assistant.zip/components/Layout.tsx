
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col max-w-md mx-auto bg-[#FDFDFD] shadow-2xl relative overflow-hidden border-x border-slate-100">
      <header className="bg-white/80 backdrop-blur-md border-b border-amber-200/30 px-6 py-5 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-amber-100 via-amber-400 to-amber-300 rounded-xl flex items-center justify-center shadow-md shadow-amber-200/50 border border-amber-200/50">
            <svg className="w-6 h-6 text-slate-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
          </div>
          <div>
            <h1 className="font-extrabold text-lg tracking-tight text-slate-900 leading-none">AI CHEF</h1>
            <p className="text-[10px] font-bold text-amber-500 tracking-[0.2em] uppercase">Assistant</p>
          </div>
        </div>
        <div className="text-[10px] font-black text-amber-700 bg-amber-100/50 border border-amber-200 px-2 py-0.5 rounded-sm tracking-tighter uppercase">Premium</div>
      </header>
      <main className="flex-1 overflow-y-auto px-6 py-6 pb-36 bg-[#FDFDFD]">
        {children}
      </main>
    </div>
  );
};
